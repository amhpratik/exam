

 
   //Questions array
            let questions = [
            {
                 number:1,
                 question: "What does HTML stand for ?",
                 answer : "Hypertext Markup Language",
                 options : [
                                  "Hypertensive Money Loan",
                                  "Hypertext Manual Log",
                                  "Hypertext Markup Language",
                                  "Hypertech Math Link"
                                ]
            
            },
            {
                 number:2,
                 question: "What does XML stand for ?",
                 answer : "eXtensible Markup Language",
                 options : [
                                  "eXtended Markup Language",
                                  "eXtensible Markup Language",
                                  "eXtension Math Link",
                                  "eXpensive Money Loan"  
                                  ]
            
            },
           {
                 number:3,
                 question: "What does URL stand for ?",
                 answer : "Uniform Resource Locator",
                 options : [ 
                                  "Universal Resource Language",
                                  "Uniform Resource Locator",
                                  "Universal Resource Locator",
                                  "University Resource Link "
                                  ]
            
            },
            {
                 number:4,
                 question: "What does HTTP stand for ?",
                 answer : "Hypertext Transfer Protocol",
                 options : [
                                  "Hypertext Transmitter Protocol",
                                  "Hypertest Transfer Protocol",
                                  "Hypertech Transit Protocol",
                                  "Hypertext Transfer Protocol"
                                  ]
            }, 
            {
                 number:5,
                 question: "What does SEO stand for ?",
                 answer : "Search Engine Optimization",
                 options : [ 
                                  "Search Engine Orientation",
                                  "Script Engine Optimization",
                                  "Script Entension Order",
                                  "Search Engine Optimization"
                               ]
            },
            {
                 number:6,
                 question: "What does API stand for ?",
                 answer : "Application Programming Interface",
                 options : [
                                  "Application Programming Interface",
                                  "Appliances Programming Interface",
                                  "Application Programming Instruction",
                                  "Appliances Programming Instruction"
                               ]
            },
            {
                 number:7,
                 question: "What does CSS stand for ?",
                 answer : "Cascading Style Sheet",
                 options : [
                                  "Colorful Style Sheet",
                                  "Cascading Sheet Style",
                                  "Cascading Style Sheet",
                                  "Creative Style Sheet"
                               ]
            },
             {
                 number:8,
                 question: "What does DOM stand for ?",
                 answer : "Document Object Model",
                 options : [
                                 "Document Object Model",
                                 "Docstring Object Model",
                                 "Doctype Object Model",
                                 "Document Object Module"
                               ]
            },
            {
                 number:9,
                 question: "What does CMS stand for ?",
                 answer : "Content Management System",
                 options : [
                                 "Content Managent System",
                                 "Content Manager System",
                                 "Content Managing System",
                                 "Content Management System"
                               ]
            }
             ];    
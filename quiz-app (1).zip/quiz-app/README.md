# quiz app

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pratik-Hirve/pen/mdoWyyx](https://codepen.io/Pratik-Hirve/pen/mdoWyyx).

